#' @title The L2-calibration method for calibrating computer model
#' @description Provides an estimates to the calibration parameter based on the physical
#' data and the computer model using the L2-calibration method and the stochastic gradient descent algorithm with adaptive stepsize (AdaGrad). The physical system is
#' estimated using kernel ridge regression with the Matern kernel with roughness parameter alpha,
#' 0 < alpha <= infinity. When alpha = infinity, the kernel function is set to the squared-exponential
#' kernel (Gaussian kernel).
#' @param Y The (noisy) repsonse from the physical system.
#' @param X The design points corresponding to the physical responses.
#' @param y_s The computer model y_s(x, theta), where x is a sequence of design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param Dy_s The derivative of y_s(x, theta), where x is a sequence of design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param theta_min A q-dimensional vector specifying the lower bound for the calibration parameter.
#' @param theta_max A q-dimensional vector specifying the upper bound for the calibration parameter.
#' @param lambda_seq A sequence of tunning parametes lambda. The optimal value of lambda is selected using
#' leave-one-out cross validation (LOOCV).
#' @param alpha The roughness parameter for the Matern kernel function. Default value is 5/2.
#' @param range The range parameter for the Matern kernel function. Default value is 1/8.
#' @param N The number of samples for AdaGrad. Default value is 2000.
#' @param N_multi The number of trials for running AdaGrad multiple times to search for the global optimum.
#' @return A list containing:
#' @return x_seq: A grid_size-by-q matrix of design points where the calibrated computer model and the estimated
#' physical system are evaluated;
#' @return eta_hat: A grid_size-dimensional vector of the estimated physical system evaluated at x_seq;
#' @return theta_L2: A q-dimensional vector of the estimated calibration parameter.
#' @examples
#' #######################################
#' # Simulate data for physical system   #
#' #######################################
#' library(lhs)
#' theta0 = c(0.2, 0.3)
#' theta_min = c(0, 0)
#' theta_max = c(0.25, 0.5)
#' y_s = function(x, theta){
#'   return(7 * (sin(2 * pi * theta[1] - pi))^2 +
#'            2 * (2 * pi * theta[2] - pi)^2 * sin(2 * pi * x - pi))
#' }
#' Dy_s = function(x, theta){
#'   n = nrow(x)
#'   Dy_s1 = 14 * sin(2 * pi * theta[1] - pi) * cos(2 * pi * theta[1] - pi) * (2 * pi)
#'   Dy_s2 = 4 * (2 * pi * theta[2] - pi) * (2 * pi) * sin(2 * pi * x - pi)
#'   Dys = matrix(NA, nrow = 2, ncol = n)
#'   Dys[1, ] = Dy_s1
#'   Dys[2, ] = Dy_s2
#'   return(Dys)
#' }
#' X = maximinLHS(50, 1)
#' n = nrow(X)
#' sig = 0.2
#' Y = y_s(X, theta0) + rnorm(nrow(X), mean = 0, sd = sig)
#' #######################################
#' # Apply the L2 calibration approach   #
#' #######################################
#' L2_calib = L2_calibration(Y, X, y_s, Dy_s, theta_min, theta_max, alpha = 3/2, range = 1/8)
#' x = sort(L2_calib$x, decreasing = FALSE, index.return = TRUE)
#' x_seq = x$x
#' eta_hat = L2_calib$eta_hat[x$ix]
#' theta_hat = L2_calib$theta_L2
#' #######################################
#' # Plot the calibrated computer model  #
#' #######################################
#' plot(X, Y, type = "p", pch = 1, xlab = "x", ylab = expression(eta),
#'      main = expression(paste("Kernel Ridge Regression for ", eta, sep = "")))
#' points(x_seq, y_s(x_seq, theta0), type = "l", lty = "dashed", lwd = 1)
#' points(x_seq, y_s(x_seq, theta_hat), type = "l", lwd = 1, col = "red")
#' legend("topleft",
#'        legend = c("Observation", "Calibrated Computer Model", "True Process"),
#'        lwd = c(1, 1, 1), pch = c(1, NA, NA), col = c("black", "red", "black"),
#'        lty = c(NA, "solid", "dashed"), bty = "n")
#' @references
#' Tuo R, Wu C F J. Efficient calibration for imperfect computer models[J]. The Annals of Statistics, 2015, 43(6): 2331-2352.
#' @export

L2_calibration = function(Y, X, y_s, Dy_s, theta_min, theta_max, lambda_seq = exp(seq(-6, -1, by = 1) * log(10)),
                          alpha = 5 / 2, range = 1 / 8, N = 2000, N_multi = 20){
  # Kernel ridge regression for the true process (emulate the true process eta)
  library(lhs)
  n = nrow(X)
  p = ncol(X)
  q = length(theta_min)
  psi = range
  # Generate N independent copies of uniform x_j^d's
  # xd = matrix(runif(N * p, min = 0, max = 1), nrow = N, ncol = p)
  xd = maximinLHS(N, k = p)
  # Leave-one-out cross validation for tuning lambda
  mse_lambda = matrix(NA, nrow = length(lambda_seq), ncol = n)
  for (i in 1:length(lambda_seq)){
      for (j in 1:n){
          if (alpha < Inf){
              K_inv_tmp = solve(Matern(matrix(X[-j, ], ncol = p), matrix(X[-j, ], ncol = p), psi, alpha) + diag(lambda_seq[i], n - 1))
              eta_emp_tmp = Matern(matrix(X[j, ], ncol = p), matrix(X[-j, ], ncol = p), psi, alpha) %*% K_inv_tmp %*% matrix(Y[-j], ncol = 1)
          }else{
              K_inv_tmp = solve(Squared_Exp(matrix(X[-j, ], ncol = p), matrix(X[-j, ], ncol = p), psi) + diag(lambda_seq[i], n - 1))
              eta_emp_tmp = Squared_Exp(matrix(X[j, ], ncol = p), matrix(X[-j, ], ncol = p), psi) %*% K_inv_tmp %*% matrix(Y[-j], ncol = 1)
          }
          mse_lambda[i, j] = (eta_emp_tmp - Y[j])^2
      }
  }
  lambda = lambda_seq[which.min(apply(mse_lambda, 1, mean))]
  if (alpha < Inf){
      K_inv = solve(Matern(X, X, psi, alpha) + diag(lambda, n))
  }else{
      K_inv = solve(Squared_Exp(X, X, psi) + diag(lambda, n))
  }
  eta_hat = Matern(xd, X, psi, alpha) %*% K_inv %*% matrix(Y, ncol = 1)
  # Parameters for AdaGrad
  alpha0 = 1
  beta0 = 1
  eps = 1 / 4
  delta_multi = rep(0, length = N_multi)
  theta_multi = matrix(NA, nrow = q, ncol = N_multi)
  theta_old_multi = maximinLHS(N_multi, k = q)
  ptm = proc.time()
  for (t in 1:N_multi){
      theta_old = theta_old_multi[t, ] * (theta_max - theta_min) + theta_min
      grad = matrix(NA, nrow = q, ncol = N)
      for (iter in 1:N){
          if (alpha < Inf){
              grad_tmp = 2 * c(y_s(xd[iter, ], theta_old) - Matern(matrix(xd[iter, ], ncol = p), X, psi, alpha) %*% K_inv %*% matrix(Y, ncol = 1)) *
              Dy_s(matrix(xd[iter, ], ncol = p), theta_old)
          }else{
              grad_tmp = 2 * c(y_s(xd[iter, ], theta_old) - Squared_Exp(matrix(xd[iter, ], ncol = p), X, psi) %*% K_inv %*% matrix(Y, ncol = 1)) *
              Dy_s(matrix(xd[iter, ], ncol = p), theta_old)
          }
          if (iter == 1){
              stepsize = alpha0 / beta0 ^ (1 / 2 + eps)
          }else{
              stepsize = alpha0 / (beta0 + apply(matrix(grad[, 1:(iter - 1)] ^ 2, nrow = q), 1, sum)) ^ (1 / 2 + eps)
          }
          grad[, iter] = grad_tmp
          theta_new = theta_old - stepsize * grad_tmp
          while (sum(theta_new < theta_max) + sum(theta_new > theta_min) < 2 * q){
              stepsize = stepsize / 2
              theta_new = theta_old - stepsize * grad_tmp
          }
          theta_old = theta_new
      }
      if (alpha < Inf){
          delta_multi[t] = mean((y_s(xd, theta_old) - c(Matern(xd, X, psi, alpha) %*% K_inv %*% matrix(Y, ncol = 1))) ^ 2)
      }else{
          delta_multi[t] = mean((y_s(xd, theta_old) - c(Squared_Exp(xd, X, psi) %*% K_inv %*% matrix(Y, ncol = 1))) ^ 2)
      }
      theta_multi[ , t] = theta_old
      if (floor(t / 5) == t / 5){
          runtime = proc.time() - ptm
          colnames(runtime) = NULL
          cat("# Trial", t, "; Objective value: ", delta_multi[t], "; Total runtime: ", ceiling(runtime[3]), "s;\n")
      }
  }
  theta_old = theta_multi[ , which.min(delta_multi)]
  return(list(x = xd, eta_hat = eta_hat, theta_L2 = theta_old))
}
