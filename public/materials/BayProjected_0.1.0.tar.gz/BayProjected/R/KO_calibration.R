#' @title The Kennedy and O'Hagan (KO) approach to computer model calibration
#' @description Draw posterior samples based on the KO calibration approach using the
#' Metroplis-Hastings MCMC method. The discrepancy function is imposed a Gaussian process
#' prior with roughness parameter alpha, 0 < alpha <= infinity.When alpha = infinity,
#' the covariance function is set to the squared-exponential covariance function.
#' @param Y The (noisy) repsonse from the physical system.
#' @param X The design points corresponding to the physical responses.
#' @param y_s The computer model y_s(x, theta), where x is a sequence of design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param theta_min A q-dimensional vector specifying the lower bound for the calibration parameter.
#' @param theta_max A q-dimensional vector specifying the upper bound for the calibration parameter.
#' @param sig The standard deviation of the noises.
#' @param tau The scaling factor of the covariance function.
#' @param thinning The thinning size for the MCMC samples. Default value is 10.
#' @param alpha The roughness parameter for the Matern covariance function. Default value is 5/2.
#' @param range The range parameter for the Matern covariance function. Default value is 1/8.
#' @param range_fix A logical value to decide whether the range parameter is sampled within MCMC.
#' @param Burn_in The number of burn-in iterations for the MCMC. Default value is 1000.
#' @param n_mc The number of posterior samples to be collected. Default value is 1000.
#' @param jump The size of random walk for the Metropolis-Hastings method.
#' @param hyper_KO A list containing a_psi (shape) and b_psi (rate) for the inverse-Gamma hyperprior for the range parameter.
#' @return A n_mc-by-q matrix where the rows are the posterior samples of theta.
#' @examples
#' #######################################
#' # Simulate data for physical system   #
#' #######################################
#' library(lhs)
#' theta0 = c(0.2, 0.3)
#' theta_min = c(0, 0)
#' theta_max = c(0.25, 0.5)
#' y_s = function(x, theta){
#'   return(7 * (sin(2 * pi * theta[1] - pi))^2 +
#'            2 * (2 * pi * theta[2] - pi)^2 * sin(2 * pi * x - pi))
#' }
#' X = maximinLHS(50, 1)
#' n = nrow(X)
#' sig = 0.2
#' Y = y_s(X, theta0) + rnorm(nrow(X), mean = 0, sd = sig)
#' #######################################
#' # Apply the KO calibration approach   #
#' #######################################
#' tau = 5
#' hyper_KO = NULL
#' hyper_KO$a_psi = hyper_KO$b_psi = 2
#' theta_KO_mc = KO_calibration(Y, X, y_s, theta_min, theta_max, sig, tau, alpha = 5/2,
#'                              range_fix = FALSE, jump = c(0.1, 0.01), hyper_KO = hyper_KO)
#' n_mc = nrow(theta_KO_mc)
#' x_seq = seq(0, 1, length = 500)
#' ys_KO = matrix(NA, nrow = n_mc, ncol = length(x_seq))
#' for (i in 1:n_mc){
#'   ys_KO[i, ] = y_s(x_seq, theta_KO_mc[i, ])
#' }
#' #######################################
#' # Plot the calibrated computer model   #
#' #######################################
#' plot(x_seq, y_s(x_seq, theta0), type = "l",
#'      lwd = 1, xlab = "x", ylab = expression(eta),
#'      ylim = c(1, 11),
#'      main = "(d) KO Calibration")
#' points(X, Y, type = "p", pch = 1)
#' points(x_seq, y_s(x_seq, apply(theta_KO_mc, 2, mean)), type = "l", lty = "dashed")
#' polygon(c(x_seq, rev(x_seq)),
#'         c(apply(ys_KO, 2, quantile, 0.975), rev(apply(ys_KO, 2, quantile, 0.025))),
#'         col = adjustcolor("grey50",alpha.f=0.5), border = FALSE)
#' legend("topleft",
#'        legend = c("Observation", "True Process", "KO Calibrated Model (mean)"), lwd = c(1, 1, 1),
#'        pch = c(1, NA, NA), lty = c(NA, "solid", "dashed"), bty = "n")
#' @references
#' Kennedy M C, O'Hagan A. Bayesian calibration of computer models[J]. Journal of the Royal Statistical Society: Series B
#' (Statistical Methodology), 2001, 63(3): 425-464.
#' @references
#' Plumlee M. Bayesian calibration of inexact computer models[J]. Journal of the American Statistical Association,
#' 2017, 112(519): 1274-1285.MLA
#' @export


KO_calibration = function(Y, X, y_s, theta_min, theta_max, sig, tau, thinning = 10, alpha = 5/2, range = 1/8, range_fix = TRUE,
                          Burn_in = 1000, n_mc = 1000, jump, hyper_KO){
    n = nrow(X)
    p = ncol(X)
    nu = alpha - 1/2
    psi = range
    q = length(theta_min)
    B = Burn_in
    log_ptheta_KO = function(theta, psi, X, Y){
        n = length(Y)
        if (alpha < Inf){
            Cov_inv = solve(tau ^ 2 * Matern(X, X, psi, alpha) + diag(sig ^ 2, n))
        }else{
            Cov_inv = solve(tau ^ 2 * Squared_Exp(X, X, psi) + diag(sig ^ 2, n))
        }
        GSS = matrix(Y - y_s(X, theta), nrow = 1) %*% Cov_inv %*% matrix(Y - y_s(X, theta), ncol = 1)
        return(c( - 0.5 * GSS + 0.5 * determinant(Cov_inv, logarithm = TRUE)$modulus[1]))
    }
    theta_KO_mc = matrix(NA, nrow = B + thinning * n_mc, ncol = q)
    theta_KO_mc[1, ] = runif(q, min = theta_min, max = theta_max)
    psi_KO_mc = rep(NA, length = B + thinning * n_mc)
    psi_KO_mc[1] = range
    ptm = proc.time()
    for (iter in 2:(B + thinning * n_mc)){
        for (j in 1:q){
            thetaj_new = runif(1, min = max(theta_KO_mc[iter - 1, j] - jump[j], theta_min[j]),
            max = min(theta_KO_mc[iter - 1, j] + jump[j], theta_max[j]))
            theta_new = theta_KO_mc[iter - 1, ]
            theta_new[j] = thetaj_new
            loglik_old = log_ptheta_KO(theta_KO_mc[iter - 1, ], psi_KO_mc[iter - 1], X, Y)
            loglik_new = log_ptheta_KO(theta_new, psi_KO_mc[iter - 1], X, Y)
            U = runif(1, min = 0, max = 1)
            if(log(U) < loglik_new - loglik_old){
                theta_KO_mc[iter, j] = thetaj_new
            }else{
                theta_KO_mc[iter, j] = theta_KO_mc[iter - 1, j]
            }
        }
        if (range_fix == TRUE){
            psi_KO_mc[iter] = range
        }else{
            psi_star = 1 / rgamma(1, shape = hyper_KO$a_psi, rate = hyper_KO$b_psi)
            loglik_old = log_ptheta_KO(theta_KO_mc[iter, ], psi_KO_mc[iter - 1], X, Y)
            loglik_new = log_ptheta_KO(theta_KO_mc[iter, ], psi_star, X, Y)
            U = runif(1, min = 0, max = 1)
            if(log(U) < loglik_new - loglik_old){
                psi_KO_mc[iter] = psi_star
            }else{
                psi_KO_mc[iter] = psi_KO_mc[iter - 1]
            }
        }
        if (iter / 500 == floor(iter / 500)){
            runtime = proc.time() - ptm
            colnames(runtime) = NULL
            cat("# Iteration", iter, "; Total runtime: ", ceiling(runtime[3]), "s;\n")
        }
    }
    theta_KO_mc = theta_KO_mc[seq(B + 1, B + thinning * n_mc, by = thinning), ]
    psi_KO_mc = psi_KO_mc[seq(B + 1, B + thinning * n_mc, by = thinning)]
    return(theta_KO_mc)
}
