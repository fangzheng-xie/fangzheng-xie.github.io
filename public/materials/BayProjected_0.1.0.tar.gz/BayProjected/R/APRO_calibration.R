#' @title Approximate projected calibration for computer models
#' @description Draw posterior samples based on the approximate projected calibration approach (see Algorithm 2 in the manuscript).
#' The physical system is imposed a Gaussian process prior with roughness parameter alpha,
#' 0 < alpha <= infinity.When alpha = infinity, the covariance function is set to the
#' squared-exponential covariance function.
#' @param Y The (noisy) repsonse from the physical system.
#' @param X The design points corresponding to the physical responses.
#' @param y_s The computer model y_s(x, theta), where x is a sequence of design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param Dy_s The derivative of y_s(x, theta) returning a q-by-m matrix, where x is a sequence of m design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param D2y_s The Hessian of y_s(x, theta), returning a q-by-q-by-m array, where x is a sequence of m design points and.
#' theta is a q-dimensional vector of the calibration parameter..
#' @param theta_min A q-dimensional vector specifying the lower bound for the calibration parameter.
#' @param theta_max A q-dimensional vector specifying the upper bound for the calibration parameter.
#' @param sig The standard deviation of the noises.
#' @param tau The scaling factor of the covariance function.
#' @param lambda_seq A sequence of tunning parametes lambda. The optimal value of lambda is selected using
#' leave-one-out cross validation (LOOCV).
#' @param alpha The roughness parameter for the Matern covariance function. Default value is 5/2.
#' @param range The range parameter for the Matern covariance function. Default value is 1/8.
#' @param n_mc The number of posterior samples to be collected. Default value is 1000.
#' @param N The number of samples for AdaGrad. Default value is 2000.
#' @param grid_size The number of points for discretization for numerical integration. Default value is 500.
#' @return A list containing:
#' @return mean: A q-dimensional vector of the mean of the approxiamte projected calibration posterior;
#' @return covariance: A q-by-q matrix of the covariance matrix of the approxiamte projected calibration posterior;
#' @return theta_mc: A n_mc-by-q matrix where the rows are the posterior samples of the calibration parameter.
#' @examples
#' #######################################
#' # Simulate data for physical system   #
#' #######################################
#' library(lhs)
#' theta0 = c(0.2, 0.3)
#' theta_min = c(0, 0)
#' theta_max = c(0.25, 0.5)
#' y_s = function(x, theta){
#'   return(7 * (sin(2 * pi * theta[1] - pi))^2 +
#'            2 * (2 * pi * theta[2] - pi)^2 * sin(2 * pi * x - pi))
#' }
#' # Derivative of the computer model
#' Dy_s = function(x, theta){
#'   n = nrow(x)
#'   Dy_s1 = 14 * sin(2 * pi * theta[1] - pi) * cos(2 * pi * theta[1] - pi) * (2 * pi)
#'   Dy_s2 = 4 * (2 * pi * theta[2] - pi) * (2 * pi) * sin(2 * pi * x - pi)
#'   Dys = matrix(NA, nrow = 2, ncol = n)
#'   Dys[1, ] = Dy_s1
#'   Dys[2, ] = Dy_s2
#'   return(Dys)
#' }
#' # Hessian of the computer model
#' D2y_s = function(x, theta){
#'   n = length(x)
#'   D2ys11 = 56 * pi ^ 2 * cos(4 * pi * theta[1])
#'   D2ys22 = - 16 * pi ^ 2 * sin(2 * pi * x)
#'   D2ys = array(0, dim = c(2, 2, n))
#'   D2ys[1, 1, ] = rep(D2ys11, length = n)
#'   D2ys[2, 2, ] = D2ys22
#'   return(D2ys)
#' }
#' X = maximinLHS(50, 1)
#' n = nrow(X)
#' sig = 0.2
#' Y = y_s(X, theta0) + rnorm(nrow(X), mean = 0, sd = sig)
#' ############################################
#' # Apply the approximate projected calibration #
#' ############################################
#' tau = 5
#' APC = APRO_calibration(Y, matrix(X, ncol = 1), y_s, Dy_s, D2y_s, theta_min, theta_max, sig, tau)
#' theta_tilde_mc = APC$theta_mc
#' n_mc = nrow(theta_tilde_mc)
#' x_seq = seq(0, 1, length = 500)
#' ys_APC = matrix(NA, nrow = n_mc, ncol = length(x_seq))
#' for (i in 1:n_mc){
#'   ys_APC[i, ] = y_s(x_seq, theta_tilde_mc[i, ])
#' }
#' #######################################
#' # Plot the calibrated computer model   #
#' #######################################
#' plot(x_seq, y_s(x_seq, theta0), type = "l",
#'      lwd = 1, xlab = "x", ylab = expression(eta),
#'      ylim = c(1, 11),
#'      main = "(d) KO Calibration")
#' points(X, Y, type = "p", pch = 1)
#' points(x_seq, y_s(x_seq, apply(theta_tilde_mc, 2, mean)), type = "l", lty = "dashed")
#' polygon(c(x_seq, rev(x_seq)),
#'         c(apply(ys_APC, 2, quantile, 0.975), rev(apply(ys_APC, 2, quantile, 0.025))),
#'         col = adjustcolor("grey50",alpha.f=0.5), border = FALSE)
#' legend("topleft",
#'        legend = c("Observation", "True Process", "Approximate Projected Calibrated Model (mean)"),
#'        lwd = c(1, 1, 1), pch = c(1, NA, NA), lty = c(NA, "solid", "dashed"), bty = "n")
#' @export

APRO_calibration = function(Y, X, y_s, Dy_s, D2y_s, theta_min, theta_max, sig, tau, lambda_seq = exp(seq(-6, -1, by = 1) * log(10)),
                            alpha = 5/2, range = 1/8, n_mc = 1000, N = 2000, grid_size = 500){
  library(mvtnorm)
  n = nrow(X)
  p = ncol(X)
  nu = alpha - 1/2
  psi = range
  q = length(theta_min)
  L2_calib = L2_calibration(Y, X, y_s, Dy_s, theta_min, theta_max, alpha = 3/2, range = 1/8, N = grid_size)
  theta_hat = L2_calib$theta_L2
  x_seq = L2_calib$x
  eta_hat = L2_calib$eta_hat
  V_hat = 2 * apply(D2y_s(x_seq, theta_hat) * c(y_s(x_seq, theta_hat) - eta_hat), c(1, 2), mean)
  W_hat = matrix(0, nrow = q, ncol = q)
  for (i in 1:nrow(x_seq)){
    V_hat = V_hat + (1 / nrow(x_seq)) * 2 * matrix(Dy_s(matrix(x_seq[i, ], ncol = p), theta_hat), ncol = 1) %*% matrix(Dy_s(matrix(x_seq[i, ], ncol = p), theta_hat), nrow = 1)
    W_hat = W_hat + (1 / nrow(x_seq)) * matrix(Dy_s(matrix(x_seq[i, ], ncol = p), theta_hat), ncol = 1) %*% matrix(Dy_s(matrix(x_seq[i, ], ncol = p), theta_hat), nrow = 1)
  }
  A = matrix(NA, nrow = nrow(W_hat), ncol = nrow(x_seq))
  for (i in 1:nrow(x_seq)){
    A[ , i] = 2 / nrow(x_seq) * solve(V_hat) %*% matrix(Dy_s(matrix(x_seq[i, ], ncol = p), theta_hat), ncol = 1)
  }
  v = 1 / sig
  if (alpha < Inf){
    C_inv = solve(Matern(X, X, psi, alpha) + diag(1 / v ^ 2, n))
  }else{
    C_inv = solve(Squared_Exp(X, X, psi) + diag(1 / v ^ 2, n))
  }
  eta_mean = rep(NA, nrow(x_seq))
  eta_cov = matrix(NA, nrow = nrow(x_seq), ncol = nrow(x_seq))
  for (i in 1:nrow(x_seq)){
    Kx = matrix(Matern(matrix(x_seq[i, ], ncol = p), X, psi, alpha), nrow = 1)
    eta_mean[i] = Kx %*% C_inv %*% matrix(Y, ncol = 1)
  }
  for (i in 1:nrow(x_seq)){
    for (j in 1:nrow(x_seq)){
      Kxi = matrix(Matern(matrix(x_seq[i, ], ncol = p), X, psi, alpha), nrow = 1)
      Kxj = matrix(Matern(matrix(x_seq[j, ], ncol = p), X, psi, alpha), ncol = 1)
      eta_cov[i, j] = sig ^ 2 * v ^ 2 * (Matern(matrix(x_seq[i, ], ncol = p), matrix(x_seq[j, ], ncol = p), psi, alpha) - Kxi %*% C_inv %*% Kxj)
    }
  }
  eta_cov = 0.5 * (eta_cov + t(eta_cov))
  theta_tilde = theta_hat - A %*% matrix(eta_hat, ncol = 1) + A %*% matrix(eta_mean, ncol = 1)
  var_tilde = A %*% eta_cov %*% t(A)
  theta_mc = rmvnorm(n_mc, mean = theta_tilde, sigma = var_tilde)
  return(list(theta_mc = theta_mc, mean = theta_tilde, covariance = var_tilde, eta_hat = eta_mean))
}
