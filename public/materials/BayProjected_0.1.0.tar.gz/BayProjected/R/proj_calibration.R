#' @title Bayesian projected calibration for computer models
#' @description Draw posterior samples based on the Bayesian projected calibration approach.
#' The physical system is imposed a Gaussian process prior with roughness parameter alpha,
#' 0 < alpha <= infinity.When alpha = infinity, the covariance function is set to the
#' squared-exponential covariance function.
#' @param Y The (noisy) repsonse from the physical system.
#' @param X The design points corresponding to the physical responses.
#' @param y_s The computer model y_s(x, theta), where x is a sequence of design points and.
#' theta is a q-dimensional vector of the calibration parameter.
#' @param theta_min A q-dimensional vector specifying the lower bound for the calibration parameter.
#' @param theta_max A q-dimensional vector specifying the upper bound for the calibration parameter.
#' @param sig The standard deviation of the noises.
#' @param tau The scaling factor of the covariance function.
#' @param alpha The roughness parameter for the Matern covariance function. Default value is 5/2.
#' @param range The range parameter for the Matern covariance function. Default value is 1/8.
#' @param n_mc The number of posterior samples to be collected. Default value is 1000.
#' @param grid_size The number of points for discretization for numerical integration. Default value is 500.
#' @return A list containing:
#' @return x_seq: A grid_size-by-q matrix of design points where the calibrated computer model and the estimated
#' physical system are evaluated;
#' @return eta_mean: A grid_size-dimensional vector the posterior mean of the physical system evaluated at x_seq;
#' @return eta_cov: A grid_size-by-grid_size matrix of the posterior covariance function evaluated at x_seq;
#' @return theta_star_mc: A n_mc-by-q matrix where the rows are the posterior samples of the calibration parameter.
#' @examples
#' #######################################
#' # Simulate data for physical system   #
#' #######################################
#' library(lhs)
#' theta0 = c(0.2, 0.3)
#' theta_min = c(0, 0)
#' theta_max = c(0.25, 0.5)
#' y_s = function(x, theta){
#'   return(7 * (sin(2 * pi * theta[1] - pi))^2 +
#'            2 * (2 * pi * theta[2] - pi)^2 * sin(2 * pi * x - pi))
#' }
#' X = maximinLHS(50, 1)
#' n = nrow(X)
#' sig = 0.2
#' Y = y_s(X, theta0) + rnorm(nrow(X), mean = 0, sd = sig)
#' ############################################
#' # Apply the Bayesian projected calibration #
#' ############################################
#' tau = 5
#' proj_calib = proj_calibration(Y, X, y_s, theta_min, theta_max, sig, tau, alpha = 5/2, range = 1/8)
#' x = sort(proj_calib$x, decreasing = FALSE, index.return = TRUE)
#' x_seq = x$x
#' eta_mean = proj_calib$eta_mean[x$ix]
#' eta_cov = proj_calib$eta_cov[x$ix, x$ix]
#' theta_star_mc = proj_calib$theta_star_mc
#' #######################################
#' # Plot the calibrated computer model   #
#' #######################################
#' plot(X, Y, type = "p", pch = 1,
#'      lwd = 2, xlab = "x", ylab = expression(eta),
#'      main = expression(paste("Posterior Samples of ", eta)))
#' points(x_seq, y_s(x_seq, theta0), type = "l", lty = "dashed", lwd = 1)
#' points(x_seq, y_s(x_seq, apply(theta_star_mc, 2, mean)),
#'        type = "l", lty = "dotted", lwd = 1, col = "blue")
#' points(x_seq, eta_mean, type = "l", lwd = 1, col = "red")
#' polygon(c(x_seq, rev(x_seq)),
#'         c(eta_mean  + sqrt(diag(eta_cov)) * qnorm(0.95),
#'           rev(eta_mean + sqrt(diag(eta_cov)) * qnorm(0.05))),
#'         col = adjustcolor("grey50",alpha.f=0.5), border = FALSE)
#' legend("topleft", legend = c("Observation", "GP Posterior Mean",
#'                              "True Process", "Calibrated Computer Model"),
#'        lwd = c(1, 1, 1, 1), pch = c(1, NA, NA, NA),
#'        lty = c(NA, "solid", "dashed", "dotted"),
#'        col = c("black", "red", "black", "blue"),
#'        bty = "n")
#' @export

proj_calibration = function(Y, X, y_s, theta_min, theta_max, sig, tau,
                            alpha = 5/2, range = 1/8, n_mc = 1000, grid_size = 500){
  library(mvtnorm)
  library(lhs)
  n = nrow(X)
  p = ncol(X)
  nu = alpha - 1/2
  psi = range
  q = length(theta_min)
  x_seq = maximinLHS(grid_size, p) # require package lhs
  # Step 1: Compute posterior distribution of physical system: Mean and covariance function
  v = tau/sig
  if (alpha < Inf){
    C_inv = solve(Matern(X, X, psi, alpha) + diag(1/v^2, n))
    eta_mean = rep(NA, nrow(x_seq))
    eta_cov = matrix(NA, nrow = nrow(x_seq), ncol = nrow(x_seq))
    for (i in 1:length(x_seq)){
      Kx = matrix(Matern(matrix(x_seq[i, ], ncol = p), X, psi, alpha), nrow = 1)
      eta_mean[i] = Kx %*% C_inv %*% matrix(Y, ncol = 1)
    }
    for (i in 1:nrow(x_seq)){
      for (j in 1:nrow(x_seq)){
        Kxi = Matern(matrix(x_seq[i, ], nrow = 1), X, psi, alpha)
        Kxj = t(Matern(matrix(x_seq[j, ], nrow = 1), X, psi, alpha))
        eta_cov[i, j] = sig^2 * v^2 * (Matern(matrix(x_seq[i, ], nrow = 1), matrix(x_seq[j, ], nrow = 1), psi, alpha) -
                                         Kxi %*% C_inv %*% Kxj)
      }
    }
  }else{
    C_inv = solve(Squared_Exp(X, X, psi) + diag(1/v^2, n))
    eta_mean = rep(NA, nrow(x_seq))
    eta_cov = matrix(NA, nrow = nrow(x_seq), ncol = nrow(x_seq))
    for (i in 1:length(x_seq)){
      Kx = matrix(Squared_Exp(matrix(x_seq[i, ], ncol = p), X, psi), nrow = 1)
      eta_mean[i] = Kx %*% C_inv %*% matrix(Y, ncol = 1)
    }
    for (i in 1:nrow(x_seq)){
      for (j in 1:nrow(x_seq)){
        Kxi = Squared_Exp(matrix(x_seq[i, ], nrow = 1), X, psi)
        Kxj = t(Squared_Exp(matrix(x_seq[j, ], nrow = 1), X, psi))
        eta_cov[i, j] = sig^2 * v^2 * (Squared_Exp(matrix(x_seq[i, ], nrow = 1), matrix(x_seq[j, ], nrow = 1), psi) -
                                         Kxi %*% C_inv %*% Kxj)
      }
    }
  }
  eta_cov = 0.5 * (eta_cov + t(eta_cov))
  # Step 2: Draw samples from the posterior distribution of theta_eta^star
  theta_star_mc = matrix(NA, nrow = n_mc, ncol = q)
  ptm = proc.time()
  for (i in 1:n_mc){
    eta_mc = rmvnorm(1, mean = eta_mean, sigma = eta_cov)
    L2_tmp_function = function(theta){
      return(mean((c(eta_mc) - c(y_s(x_seq, theta)))^2))
    }
    theta_star_mc[i, ] = optim(runif(q, theta_min, theta_max), fn = L2_tmp_function, method = "L-BFGS-B",
                               lower = theta_min, upper = theta_max)$par
    if (floor(i/100) == i/100){
      runtime = proc.time() - ptm
      colnames(runtime) = NULL
      print(paste("Iteration: ", i, "; Total runtime: ", ceiling(runtime[3]), "s", sep = ""))
    }
  }
  return(list(x = x_seq, eta_mean = eta_mean, eta_cov = eta_cov, theta_star_mc = theta_star_mc))
}
