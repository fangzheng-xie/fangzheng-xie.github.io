#include <Rcpp.h>
#include <R.h>
#include <assert.h>

using namespace Rcpp;

// [[Rcpp::export]]
NumericMatrix Matern(NumericMatrix x1, NumericMatrix x2, double psi, double alpha){
  int n1 = x1(_, 0).size();
  int n2 = x2(_, 0).size();
  int nu = alpha - 1/2;
  NumericMatrix Cov_mat(n1, n2);
  for (int i = 0; i < n1; i ++){
    for (int j = 0; j < n2; j ++){
      double d = sqrt(sum((x1(i, _) - x2(j, _)) * (x1(i, _) - x2(j, _))))/psi;
      NumericVector matern_tmp(nu + 1);
      if (d >= pow(10, -6)){
        for (int k = 0; k < nu + 1; k ++){
          matern_tmp[k] = exp(R::lgammafn(nu + 1) - R::lgammafn(2 * nu + 1) + R::lgammafn(nu + k + 1) - 
            R::lgammafn(nu - k + 1) - R::lgammafn(k + 1) + (nu - k) * log(sqrt(8 * (nu + 1/2)) * d) - sqrt(2 * (nu + 1/2)) * d);
        }
        Cov_mat(i, j) = sum(matern_tmp);
      }
      else
      {
        Cov_mat(i, j) = 1;
      }
    }
  }
  return(Cov_mat);
}

// [[Rcpp::export]]
NumericMatrix Squared_Exp(NumericMatrix x1, NumericMatrix x2, double psi){
  int n1 = x1(_, 0).size();
  int n2 = x2(_, 0).size();
  NumericMatrix Cov_mat(n1, n2);
  for (int i = 0; i < n1; i ++){
    for (int j = 0; j < n2; j ++){
      double d = sqrt(sum((x1(i, _) - x2(j, _)) * (x1(i, _) - x2(j, _))))/psi;
      Cov_mat(i, j) = exp( - d * d/2);
    }
  }
  return(Cov_mat);
}

