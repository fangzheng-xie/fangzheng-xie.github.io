
#include <RcppEigen.h>
// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;

NumericVector nabla_l_in_jC(NumericVector x,
                            int i, int j,
                            NumericMatrix A,
                            NumericMatrix X_tilde,
                            NumericMatrix P_tilde);
NumericVector nabla_l_inC_loop(NumericVector x,
                               int i, int n, int d,
                               NumericMatrix A,
                               NumericMatrix X_tilde,
                               NumericMatrix P_tilde);

//[[Rcpp::export]]
NumericMatrix msle_sgd_C(NumericMatrix A,
                         NumericMatrix X_tilde,
                         NumericMatrix P_tilde,
                         double a_0, double b_0, double epsilon,
                         double tolerance,
                         const unsigned int batch_size,
                         unsigned int max_nepoch,
                         bool show_message)
{
    const unsigned int n = X_tilde.nrow(), d = X_tilde.ncol();
    unsigned int max_niter = (n/batch_size + ((n%batch_size==0)?0:1)) * max_nepoch;
    NumericMatrix X_hat(n,d);
    for (int i = 0; i < n; i++)
    {
        unsigned int t = 0;
        unsigned int e_t = 0;
        double grad_history_sum = 0;
        double step_size = 0;
        NumericVector x_temp_vec(d);
        NumericVector curr_grad(d);
        NumericVector curr_grad_sto(d);
        IntegerVector ind_shuffled(n);
        
        x_temp_vec = X_tilde(i,_);
        curr_grad = nabla_l_inC_loop(x_temp_vec, i, n, d, A, X_tilde, P_tilde);
        grad_history_sum = grad_history_sum + sum(pow(curr_grad, 2));
    
        bool converged = false;
        while((!converged) && (t < max_niter))
        {
            ind_shuffled = sample(n,n) - 1;
            
            for (int j = 0; j < n - batch_size + 1; j = j + batch_size)
            {
                curr_grad_sto = curr_grad_sto * 0;
                step_size = a_0 * pow(b_0 + grad_history_sum, -(0.5+epsilon));
                for (int kb = 0; kb < batch_size; kb++)
                    curr_grad_sto = curr_grad_sto + nabla_l_in_jC(x_temp_vec, i, ind_shuffled(j + kb), A, X_tilde, P_tilde);
                curr_grad_sto = curr_grad_sto / batch_size;
                grad_history_sum = grad_history_sum + sum(pow(curr_grad_sto, 2));
                x_temp_vec = x_temp_vec + step_size * curr_grad_sto;
                t++;
            }
            
            if(n%batch_size != 0)
            {
                curr_grad_sto = curr_grad_sto * 0;
                step_size = a_0 * pow(b_0 + grad_history_sum, -(0.5+epsilon));
                for (int kb = 0; kb < n%batch_size; kb++)
                    curr_grad_sto = curr_grad_sto + nabla_l_in_jC(x_temp_vec, i, ind_shuffled(n-1-kb), A, X_tilde, P_tilde);
                curr_grad_sto = curr_grad_sto / (n%batch_size);
                grad_history_sum = grad_history_sum + sum(pow(curr_grad_sto, 2));
                x_temp_vec = x_temp_vec + step_size * curr_grad_sto;
                t++;
            }
            
            // if(batch_size == n)
            //     curr_grad = curr_grad_sto;
            // else
                curr_grad = nabla_l_inC_loop(x_temp_vec, i, n, d, A, X_tilde, P_tilde);
            
            e_t++;
            converged = sum(curr_grad * curr_grad) < pow(tolerance, 2);
            
            if(e_t%20000==0)
            {
                grad_history_sum = 0;
                grad_history_sum = grad_history_sum + sum(pow(curr_grad, 2));
                grad_history_sum = (e_t/10000 * e_t/10000) * (b_0 + grad_history_sum);
            }
      
            // Rcout << "i: " << i << std::endl;
            // Rcout << "t: " << t << std::endl;
            // Rcout << "l2 norm of gradient: " << sqrt(sum(curr_grad * curr_grad)) << std::endl;
            // Rcout << " " << std::endl;
        }
        X_hat(i,_) = x_temp_vec;
        
        if( (!(t<max_niter)) || show_message )
        {
            Rcout << "vertex index: " << i+1 << std::endl;
            Rcout << "number of epochs: " << e_t << std::endl;
            Rcout << "number of iterations: " << t << std::endl;
            Rcout << "maximum number of iterations: " << max_niter << std::endl;
            Rcout << "l2 norm of gradient: " << sqrt(sum(curr_grad * curr_grad)) << std::endl;
            Rcout << " " << std::endl;
        }
        
        // if(i%100==0)
        //     Rcout << i << std::endl;
    }
    
    return X_hat;
}











// the single gradient, with Huber correction
NumericVector nabla_l_in_jC(NumericVector x,
                            int i, int j,
                            NumericMatrix A,
                            NumericMatrix X_tilde,
                            NumericMatrix P_tilde)
{
    double tau = std::min( 1e-2, sqrt(abs(P_tilde(i,j))) );
    double t = sum(X_tilde(j,_) * x);
    if(A(i,j)==1.0)
        return (1/abs(P_tilde(i,j)) * (1-t) + 1) * X_tilde(j,_);
    else if(t < 1-tau)
        return - t * (1/abs(P_tilde(i,j)) + 1/(1-t)) * X_tilde(j,_);
    else
    {
        // double alpha_ij = - 0.5 * (1/abs(P_tilde(i,j)) + 1/pow(tau,2));
        // double beta_ij = pow((1-tau)/tau, 2);
        return (- (1/abs(P_tilde(i,j)) + 1/pow(tau,2)) * t + pow((1-tau)/tau, 2)) * X_tilde(j,_);
    }
}

// the average gradient, implemented via a for loop
NumericVector nabla_l_inC_loop(NumericVector x,
                               int i, int n, int d,
                               NumericMatrix A,
                               NumericMatrix X_tilde,
                               NumericMatrix P_tilde)
{
    NumericVector out(d);
    for(int j = 0; j < n; j++)
        out = out + nabla_l_in_jC(x, i, j, A, X_tilde, P_tilde);
    out = out/n;
    return out;
}


