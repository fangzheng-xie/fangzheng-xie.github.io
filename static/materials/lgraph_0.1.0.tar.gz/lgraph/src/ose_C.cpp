
#include <RcppEigen.h>

// [[Rcpp::depends(RcppEigen)]]

using namespace Rcpp;
using Eigen::Map;                       // 'maps' rather than copies
using Eigen::MatrixXd;                  // variable size matrix, double precision
using Eigen::VectorXd;                  // variable size vector, double precision


// [[Rcpp::export]]
NumericMatrix ose_C(NumericMatrix A_nm, NumericMatrix X_tilde_nm)
{
    // double tau = 1e-2; // for Huber loss function
    const unsigned int n = X_tilde_nm.nrow(), d = X_tilde_nm.ncol();
    NumericMatrix X_hat(n, d);
    // turn Rcpp objects into RcppEigen objects
    Map<MatrixXd> X_tilde(as<Map<MatrixXd>>(X_tilde_nm));
    
    NumericVector A_nmi(n), X_tilde_nmi(d);
    VectorXd Ai(n), X_tildei(d), temp(n), denom(n), grad(d);
    MatrixXd nG_in_tilde(d, d);
    for(int i = 0; i < n; i++)
    {
        A_nmi = A_nm(i,_);
        X_tilde_nmi = X_tilde_nm(i,_);
        Map<VectorXd> Ai(as<Map<VectorXd>>(A_nmi));
        Map<VectorXd> X_tildei(as<Map<VectorXd>>(X_tilde_nmi));
        temp = X_tilde * X_tildei;
        denom = temp.array() * (1.0 - temp.array());
        denom = denom.array().abs();
        // denom = (denom.array() < tau).select(tau, denom);
        nG_in_tilde = X_tilde.transpose() * denom.array().inverse().matrix().asDiagonal() * X_tilde;
        temp = ((Ai - temp).array() / denom.array());
        grad = X_tilde.transpose() * temp;
        NumericVector X_hati(wrap(X_tildei + nG_in_tilde.inverse() * grad));
        X_hat(i,_) = X_hati;
        // if(i%100==0)
        //   Rcout << i << std::endl;
    }
    
    return X_hat;
}

