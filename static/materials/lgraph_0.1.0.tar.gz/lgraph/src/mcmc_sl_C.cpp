
#include <RcppEigen.h>

// [[Rcpp::depends(RcppEigen)]]

using namespace Rcpp;
using Eigen::Map;                       // 'maps' rather than copies
using Eigen::MatrixXd;                  // variable size matrix, double precision
using Eigen::VectorXd;                  // variable size vector, double precision
using Eigen::LLT;

NumericMatrix compute_cov_mat_sqrt(int i, NumericMatrix X_tilde_nm);
// NumericVector rtcmvnorm(int d, NumericVector mean_vec_nv, NumericMatrix sqrt_cov_mat_nm);
NumericVector rmvnorm(int d, NumericVector mean_vec_nv, NumericMatrix sqrt_cov_mat_nm);
double surr_log_lik(NumericVector x_nv, int i, int n, int d,
                    NumericMatrix A_nv, NumericMatrix X_tilde_nv, NumericMatrix P_tilde_nv);


// [[Rcpp::export]]
List mcmc_sl_C(NumericMatrix A,
               NumericMatrix X_tilde,
               NumericMatrix P_tilde,
               int i,
               const int d,
               double sigma,
               const unsigned int nchain,
               const unsigned int burnin,
               const unsigned int thinning)
{
    int n = A.nrow();
    NumericMatrix x_chain(d, nchain + burnin);
    NumericVector x_curr(d), x_new(d);
    x_chain(_,0) = X_tilde(i,_);
    x_curr = X_tilde(i,_);
    LogicalVector accept_record(thinning * (nchain + burnin));
    
    NumericMatrix cov_mat_sqrt = sigma * compute_cov_mat_sqrt(i, X_tilde);
    for(int t = 0; t < (nchain + burnin - 1); t++)
    {
        for(int tt = 0; tt < thinning; tt++)
        {
            x_new =  rmvnorm(d, x_curr, cov_mat_sqrt);
            accept_record(t*thinning + tt + 1) = 
                log(runif(1)[0]) < n*surr_log_lik(x_new, i, n, d, A, X_tilde, P_tilde) - n*surr_log_lik(x_curr, i, n, d, A, X_tilde, P_tilde);
            if(accept_record(t*thinning + tt + 1))
            x_curr = x_new;
        }
        x_chain(_,t+1) = x_curr;
    }
    
    NumericVector post_mean(d);
    double accept_rate;
    post_mean = rowMeans(x_chain(_,Range(burnin, nchain + burnin - 1)));
    accept_rate = mean(accept_record[Range(thinning*burnin, thinning*(nchain + burnin) - 1)]);
    
    List out = List::create(Named("post_mean") = post_mean,
                            Named("accept_rate") = accept_rate,
                            Named("chain") = x_chain(_,Range(burnin, nchain + burnin -1)));
    return(out);
}


















// compute the square root of the covariance matrix
NumericMatrix compute_cov_mat_sqrt(int i, NumericMatrix X_tilde_nm)
{
    // double tau = 1e-5;
    const unsigned int n = X_tilde_nm.nrow(), d = X_tilde_nm.ncol();
    NumericVector xi_nv(d);
    xi_nv = X_tilde_nm(i,_);
    // turn Rcpp objects into RcppEigen objects
    Map<VectorXd> xi(as<Map<VectorXd>>(xi_nv));
    Map<MatrixXd> X_tilde(as<Map<MatrixXd>>(X_tilde_nm));
    VectorXd temp_vec = X_tilde * xi;
    VectorXd denom = temp_vec.array() * (1.0 - temp_vec.array());
    denom = denom.array().abs();
    // denom = (denom.array() < tau).select(tau, denom);
    MatrixXd nG_in_tilde = X_tilde.transpose() * denom.array().inverse().matrix().asDiagonal() * X_tilde;
    LLT<MatrixXd> llt(nG_in_tilde.inverse());
    MatrixXd res = llt.matrixL();
    NumericMatrix res_nm(wrap(res));
    return res_nm;
}





// // truncated multivariate normal distribution
// NumericVector rtcmvnorm(int d, NumericVector mean_vec_nv, NumericMatrix sqrt_cov_mat_nm)
// {
//     // turn Rcpp objects into RcppEigen objects
//     Map<MatrixXd> sqrt_cov_mat(as<Map<MatrixXd>>(sqrt_cov_mat_nm));
//     Map<VectorXd> mean_vec(as<Map<VectorXd>>(mean_vec_nv));
//     VectorXd res;
//     bool out_of_ball = true;
//     while(out_of_ball)
//     {
//         // the next line shows how to convert a NumericVector to a VectorXd
//         Map<VectorXd> x(as<Map<VectorXd>>(rnorm(d)));
//         x = sqrt_cov_mat * x + mean_vec;
//         if (x.array().pow(2).sum() < 1.0)
//         {
//             res = x;
//             out_of_ball = false;
//         }
//     }
//     // turn RcppEigen objects into Rcpp objects
//     NumericVector res_nv(wrap(res));
//     return res_nv;
// }


// multivariate normal distribution
NumericVector rmvnorm(int d, NumericVector mean_vec_nv, NumericMatrix sqrt_cov_mat_nm)
{
    // turn Rcpp objects into RcppEigen objects
    Map<MatrixXd> sqrt_cov_mat(as<Map<MatrixXd>>(sqrt_cov_mat_nm));
    Map<VectorXd> mean_vec(as<Map<VectorXd>>(mean_vec_nv));
    Map<VectorXd> res(as<Map<VectorXd>>(rnorm(d)));
    res = sqrt_cov_mat * res + mean_vec;
    // turn RcppEigen objects into Rcpp objects
    NumericVector res_nv(wrap(res));
    return res_nv;
}








// // surrogate likelihood function
// double surr_log_lik(NumericVector x_nv, int i, int n, int d,
//                     NumericMatrix A_nv, NumericMatrix X_tilde_nv, NumericMatrix P_tilde_nv)
// {
//     // turn Rcpp objects into RcppEigen objects
//     Map<VectorXd> x(as<Map<VectorXd>>(x_nv));
//     Map<MatrixXd> A(as<Map<MatrixXd>>(A_nv));
//     Map<MatrixXd> X_tilde(as<Map<MatrixXd>>(X_tilde_nv));
//     Map<MatrixXd> P_tilde(as<Map<MatrixXd>>(P_tilde_nv));
//     
//     VectorXd Ai{A.row(i)};
//     VectorXd pi{P_tilde.row(i)};
//     pi = pi.array().abs();
//     
//     VectorXd temp(n), res_vec(n);
//     temp = X_tilde * x;
//     res_vec = (Ai.array()/pi.array() + 1.0) * temp.array() -
//     (temp.array().pow(2)) / ((2.0*pi).array()) +
//     (1.0-Ai.array()) * (1.0-temp.array()).log();
//     
//     return res_vec.mean();
// }


// surrogate likelihood function, with quadratic concatenation
double surr_log_lik(NumericVector x_nv, int i, int n, int d,
                    NumericMatrix A_nv, NumericMatrix X_tilde_nv, NumericMatrix P_tilde_nv)
{
    // turn Rcpp objects into RcppEigen objects
    Map<VectorXd> x(as<Map<VectorXd>>(x_nv));
    Map<MatrixXd> A(as<Map<MatrixXd>>(A_nv));
    Map<MatrixXd> X_tilde(as<Map<MatrixXd>>(X_tilde_nv));
    Map<MatrixXd> P_tilde(as<Map<MatrixXd>>(P_tilde_nv));
    
    VectorXd Ai{A.row(i)};
    VectorXd pi{P_tilde.row(i)};
    pi = pi.array().abs();
    
    VectorXd thres_vec = (pi.array().sqrt() < 1e-2).select(pi.array().sqrt(), 1e-2);
    
    VectorXd temp_2(n), res_vec_2(n);
    temp_2 = X_tilde * x;
    res_vec_2 = - 0.5 * (pi.array().inverse() + thres_vec.array().square().inverse()) * temp_2.array().square()
        + ((1 - thres_vec.array()) / thres_vec.array()).square() * temp_2.array()
        + (1 - thres_vec.array()) * (3*thres_vec.array() - 1) / (2*thres_vec.array().square()) + thres_vec.array().log();
    
    VectorXd temp_1(n), res_vec_1(n);
    temp_1 = (temp_2.array() > (1.0 - thres_vec.array())).select(1.0 - thres_vec.array(), temp_2);
    res_vec_1 = (Ai.array()/pi.array() + 1.0) * temp_1.array() -
        (temp_1.array().pow(2)) / ((2.0*pi).array()) +
        (1.0-Ai.array()) * (1.0-temp_1.array()).log();
    
    VectorXd res_vec = (temp_2.array() > (1.0 - thres_vec.array())).select(res_vec_2, res_vec_1);
    return res_vec.mean();
}



