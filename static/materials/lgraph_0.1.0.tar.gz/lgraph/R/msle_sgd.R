
# this is a wrapper


# main function
msle_sgd <- function(A, d,
                     a_0 = 1, b_0 = 1, epsilon = 0.5,
                     tolerance = 1,
                     batch_size = 1,
                     max_nepoch = 1e5,
                     show_message = FALSE)
{
    if(!is.matrix(x = A))
        stop("Please supply a matrix")
    if(!isSymmetric(object = A))
        stop("Please supply a symmetric matrix")
    if(!all(A==1 | A==0))
        stop("Please supply an adjacency matrix")
    if(!all(c(d>=1, length(d)==1)))
        stop("The embedding dimension d should be a positive integer.")
    
    if(!all(c(a_0>0, b_0>0)))
        stop("The tuning parameters a_0 and b_0 should all be greater than 0")
    if(!all(c(epsilon > 0, epsilon <= 0.5)))
        stop("The tuning parameter epsilon should be in the interval (0, 0.5].")
    if(tolerance < 0)
        stop("The tolerance of convergence should be greater than 0")
    if(!all(c(batch_size >= 1, batch_size <= dim(A)[1])))
        stop("The batch size should be between 1 and the sample size")
    if(max_nepoch < 2)
        stop("The maximum number of epochs is too small")
    
    X_tilde = ase(A, d)
    P_tilde = X_tilde %*% t(X_tilde)
    
    X_msle = msle_sgd_C(A = A, X_tilde = X_tilde, P_tilde = P_tilde,
                        a_0 = a_0, b_0 = b_0, epsilon = epsilon,
                        tolerance = tolerance,
                        batch_size = batch_size,
                        max_nepoch = max_nepoch,
                        show_message = show_message)
    
    return(X_msle)
}



