
mcmc_sl <- function(A, d, sigma = 1,
                    nchain = 10000, burnin = 2000,
                    thinning = 1,
                    parallel = TRUE)
{
    if(!is.matrix(x = A))
        stop("Please supply a matrix")
    if(!isSymmetric(object = A))
        stop("Please supply a symmetric matrix")
    if(!all(A==1 | A==0))
        stop("Please supply an adjacency matrix")
    if(!all(c(d>=1, length(d)==1)))
        stop("The embedding dimension d should be a positive integer.")
    if(sigma < 0)
        stop("The parameter for variance should be positive.")
    if(!all(c(nchain>10, burnin>10)))
        stop("The chain is too short.")
    if(thinning < 1)
        stop("The thinning width should be a positive integer.")
  
    X_tilde = ase(A, d)
    P_tilde = X_tilde %*% t(X_tilde)
  
    res = parallel::mclapply(X = (1:n)-1,
                             FUN = function(i){mcmc_sl_C(A = A, X_tilde = X_tilde, P_tilde = P_tilde,
                                                         i = i, d = d, sigma = sigma,
                                                         nchain = nchain, burnin = burnin, thinning = thinning)},
                             mc.cores = ifelse(test = parallel, yes = parallel::detectCores(), no = 1))

    post_mean = t(sapply(X = res, FUN = function(x){x$post_mean}))
    accept_rate = sapply(X = res, FUN = function(x){x$accept_rate})
    chain_array = abind::abind(lapply(X = res, function(x){x$chain}), along = 3)

    out_list = list(post_mean = post_mean, accept_rate = accept_rate, chain_array = chain_array)
    return(out_list)
}


