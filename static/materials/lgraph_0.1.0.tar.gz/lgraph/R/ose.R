
# this is a wrapper

ose <- function(A, d)
{
    if(!is.matrix(A))
        stop("Please supply a matrix")
    if(!isSymmetric(A))
        stop("Please supply an adjacency matrix")
    if(!all(A==1 | A==0))
        stop("Please supply an adjacency matrix")
    if(!all(c(d>=1, length(d)==1)))
        stop("The embedding dimension d should be a positive integer.")
    
    X_tilde = ase(A, d)
    
    X_OSE = ose_C(A_nm = A, X_tilde_nm = X_tilde)
    return (X_OSE)
}