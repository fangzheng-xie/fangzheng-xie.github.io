

ase <- function(A, d)
{
    if(!is.matrix(x = A))
        stop("Please supply a matrix")
    if(!isSymmetric(object = A))
        stop("Please supply a symmetric matrix")
    if(!all(A==1 | A==0))
        stop("Please supply an adjacency matrix")
    if(!all(c(d>=1, length(d)==1)))
        stop("The embedding dimension d should be a positive integer.")
    
    eigen_A = RSpectra::eigs_sym(A = 1.0*A, k = d, which = "LM") # much faster than eigen()
    X_ASE = eigen_A$vectors[, 1:d, drop = FALSE] %*% diag(sqrt(abs(eigen_A$values[1:d])), nrow = d) # the adjacency spectral embedding
    
    return(X_ASE)
}