#' The KIRC dataset
#'
#' Contents: KIRC read counts, subclone-specific gene expression, subclonal proportions
#'
#' @details
#' We obtain gene level read counts (Liao et al., 2014) for 200 TCGA kidney renal
#' clear cell carcinoma (KIRC) tumor RNA-seq samples and analyze them with BayCount.
#' Among a total of 23,368 genes, 966 significantly mutated genes (Network et al., 2013) in
#' KIRC patients are selected, including VHL, PTEN, MTOR, etc. BayCount yields an estimate
#' of five subclones in KIRC.
#'
#' @format
#' \describe{
#'   \item{Y}{The observed 966 * 200 count matrix}
#'   \item{Phi_hat}{The 966 * 5 estimated subclone-specific gene expression matrix}
#'   \item{Theta}{The 5 * 200 subclonal proportion matrix}
#' }
#'
#' @examples
#' attach(BayCount_KIRC)
#' library(gplots)
#' G = dim(Y)[1]
#' S = dim(Y)[2]
#' K = dim(Phi_hat)[2]
#' ###############################################################
#' # Heatmap of Subclonal proportions (Figure S12 in the manuscript)
#' ###############################################################
#' my_palette = colorRampPalette(c("white", "red"))(n = 299)
#' Col_vec = c("black", "red", "green3", "blue", "cyan", "magenta", "yellow", "gray")
#' pdf("Figure_S12.pdf", width = 8, height = 12)
#' heatmap.2(t(Theta), trace = "none", Rowv = TRUE, Colv = NULL, key.xlab = "", key.ylab = "",
#'           labCol = "", labRow = "",
#'           dendrogram = "row", col = my_palette, key = TRUE, margins = c(3, 0),
#'           key.par = list(mar = c(3.5, 0,3, 0)), denscol = NULL, symkey = FALSE,
#'           breaks = seq(0, 1, length = 300), key.title = "",
#'           lmat=rbind(c(5, 4, 3), c(2, 1, 6)), lhei=c(0.5, 5), lwid=c(1.5, 10, 1.5))
#' dev.off()
#' ###############################################################
#' # Heatmaps of gene expression data (Figure 8b in the manuscript)
#' ###############################################################
#' Col_vec = c("black", "red", "green3", "blue", "cyan", "magenta", "yellow", "gray")
#' my_palette = brewer.pal(9, "Blues")
#' rownames(Phi_hat) = rownames(Y)
#' log_Phi_hat = log(Phi_hat)
#' log_exp_thrhd = -5.5
#' log_Phi_hat[arrayInd(which(log_Phi_hat < log_exp_thrhd + 1), .dim = c(G, K))] = log_exp_thrhd
#' sd_gene = apply(log_Phi_hat, 1, sd)
#' diff_exp_gene = sort(sd_gene, decreasing = T, index.return = TRUE)$ix[1:30]
#' pdf("Figure_8b.pdf", width = 8, height = 9)
#' heatmap.2(log_Phi_hat[diff_exp_gene, ], Rowv = T, Colv = F, dendrogram = 'none', trace = 'none',
#'           col = my_palette, ColSideColors = Col_vec[2:6], symkey = FALSE,
#'           key.par = list(mar= c(2, 4, 4, 4)), cexCol = 5, cexRow = 2,
#'           breaks = seq(min(log_Phi_hat), max(log_Phi_hat), length = 10),
#'           key.title = "", key.ylab = "", key.xlab = "", denscol = NULL,
#'           key = TRUE, lhei = c(0.8, 0.3, 5), lwid = c(0.2, 1.2, 0.2),
#'           lmat = rbind(c(4, 5, 6), c(7, 1, 8), c(9, 2, 3)))
#' dev.off()
#' detach(BayCount_KIRC)

"BayCount_KIRC"
