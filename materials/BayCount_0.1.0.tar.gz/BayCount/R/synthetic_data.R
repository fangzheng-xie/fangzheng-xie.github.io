#' A medium scale synthetic data
#'
#' Generated with G = 100, S = 20, K = 3 under scenario II; Used in Section 3.1 in the manuscript
#'
#' @format
#' \describe{
#'   \item{Y}{The observed 100 * 20 count matrix}
#'   \item{alpha}{The normalized gene-specific random effect, 100-dimensional}
#'   \item{Theta}{The 3 * 20 subclonal frequency matrix}
#'   \item{Theta_norm}{The 3 * 20 subclonal proportion matrix}
#'   \item{Phi}{The 100 * 3 gene expression matrix}
#'   \item{Phi_norm}{The 100 * 3 normalized gene expression matrix}
#'   \item{PhiTheta}{The 100 * 20 matrix computed by Phi * Theta}
#'   \item{p}{The success probability vector for the NB model, 20-dimensional}
#' }
#'
#' @examples
#' library(RColorBrewer)
#' library(gplots)
#' ###############################################################
#' # Subclonal proportions
#' ###############################################################
#' G = 100
#' S = 20
#' K = 3
#' pdf("subclonal_proportions.pdf", width = 9, height = 9)
#' par(mfrow=c(K, 1))
#' for (k in 1:K){
#'   plot(1:S, type = "n", xlab = "Samples", ylab = "Proportions",
#'        ylim = c(0, 1),
#'        main = paste("Subclone ",k, " Proportion", sep = ""), cex.main = 2, cex.axis = 1.5, cex.lab = 1.5)
#'   grid(nx = 10, ny = 5, lwd = 1)
#'   points(1:S, synthetic_data$Theta_norm[k, ], type = "b",pch = 2, col = "red", lwd = 3, lty = 1)
#' }
#' dev.off()
#' ###############################################################
#' # Heatmaps of gene expression data                            #
#' ###############################################################
#' sd_gene = apply(synthetic_data$Phi_norm, 1, sd)
#' tau_sd = 1/G
#' diff_exp_gene = which(sd_gene > tau_sd)
#' my_palette = brewer.pal(9, "Blues")
#' pdf("Figure_3a.pdf", width = 5, height = 9)
#' heatmap.2(synthetic_data$Phi_norm[diff_exp_gene, ], trace = "none", Rowv = NULL, Colv = NULL,
#'           dendrogram = "none", col = my_palette, key = TRUE, margins = c(3, 0),
#'           key.par = list(mar = c(2, 0,3, 0)), denscol = "black", key.xlab = "", key.ylab = "",
#'           key.title = "", labRow = "", cexCol = 4, lhei = c(0.8, 5), lwid = c(0.2, 1.2, 0.2),
#'           lmat=rbind(c(5, 4, 2), c(6, 1, 3)))
#' dev.off()
#'
"synthetic_data"
