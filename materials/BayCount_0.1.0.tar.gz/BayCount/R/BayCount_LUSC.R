#' The LUSC dataset
#'
#' Contents: LUSC read counts, subclone-specific gene expression, subclonal proportions
#'
#' @details
#' We apply the proposed BayCount model to the TCGA RNA-Seq
#' data in lung squamous cell carcinoma (LUSC), which is a
#' common type of lung cancer that causes nearly one million
#' 18 deaths worldwide every year. The raw RNA-Seq data for
#' 200 LUSC tumor samples were processed using the Subread
#' algorithm in the Rsubread package (Liao et al., 2014) to
#' obtain gene level read counts (Rahman et al., 2015).
#' We select 382 previously reported important lung cancer
#' genes (Wilkerson et al., 2010) for analysis, such as KRAS,
#' STK11, BRAF, and RIT1. BayCount yields an estimate of five
#' subclones.
#'
#' @format
#' \describe{
#'   \item{Y}{The observed 382 * 200 count matrix}
#'   \item{Phi_hat}{The 382 * 5 estimated subclone-specific gene expression matrix}
#'   \item{Theta}{The 5 * 200 subclonal proportion matrix}
#' }
#'
#' @examples
#' attach(BayCount_LUSC)
#' library(gplots)
#' G = dim(Y)[1]
#' S = dim(Y)[2]
#' K = dim(Phi_hat)[2]
#' ###############################################################
#' # Heatmap of Subclonal proportions (Figure 6 in the manuscript)
#' ###############################################################
#' my_palette = colorRampPalette(c("white", "red"))(n = 299)
#' Col_vec = c("black", "red", "green3", "blue", "cyan", "magenta", "yellow", "gray")
#' pdf("Figure_6.pdf", width = 8, height = 12)
#' heatmap.2(t(Theta), trace = "none", Rowv = TRUE, Colv = NULL, key.xlab = "", key.ylab = "",
#'           labCol = "", labRow = "",
#'           dendrogram = "row", col = my_palette, key = TRUE, margins = c(3, 0),
#'           key.par = list(mar = c(3.5, 0,3, 0)), denscol = NULL, symkey = FALSE,
#'           breaks = seq(0, 1, length = 300), key.title = "",
#'           lmat=rbind(c(5, 4, 3), c(2, 1, 6)), lhei=c(0.5, 5), lwid=c(1.5, 10, 1.5))
#' dev.off()
#' ###############################################################
#' # Heatmaps of gene expression data (Figure 7b in the manuscript)
#' ###############################################################
#' sd_gene = apply(Phi_hat, 1, sd)
#' diff_exp_gene = sort(sd_gene, decreasing = TRUE, index.return = TRUE)$ix[1:27]
#' my_palette = brewer.pal(9, "Blues")
#' lung_gene_extra = c("KRAS", "EGFR", "FGFR", "JAK", "BRAF")
#' ind_extra = c()
#' for (ind in 1:length(lung_gene_extra)){
#'   ind_extra = c(ind_extra, grep(lung_gene_extra[ind], rownames(Phi_hat)))
#' }
#' rownames(Phi_hat) = rownames(Y)
#' Col_vec = c("black", "red", "green3", "blue", "cyan", "magenta", "yellow", "gray")
#' pdf("Figure_7b.pdf", width = 8, height = 9)
#' heatmap.2(Phi_hat[sort(c(diff_exp_gene, ind_extra)), ], Rowv = T, Colv = F, dendrogram = 'none', trace = 'none',
#'           col = my_palette, ColSideColors = Col_vec[2:6], symkey = FALSE,
#'           key.par = list(mar= c(2, 4, 4, 4)), cexCol = 5, cexRow = 2,
#'           breaks = seq(min(Phi_hat[sort(c(diff_exp_gene, ind_extra)), ]),
#'                        max(Phi_hat[sort(c(diff_exp_gene, ind_extra)), ]),
#'                        length = 10),
#'           key.title = "", key.ylab = "", key.xlab = "", denscol = NULL,
#'           key = TRUE, lhei = c(0.8, 0.3, 5), lwid = c(0.2, 1.2, 0.2),
#'           lmat = rbind(c(4, 5, 6), c(7, 1, 8), c(9, 2, 3)))
#' dev.off()
#' detach(BayCount_LUSC)
"BayCount_LUSC"
