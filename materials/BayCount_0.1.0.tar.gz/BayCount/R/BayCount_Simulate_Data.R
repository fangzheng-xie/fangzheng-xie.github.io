#' @title Simulate data from BayCount model
#' @description This function generate data from the existing
#' @param G number of genes
#' @param S number of tumor samples
#' @param K number of subclones
#' @param Phi_par shape parameter for the Dirichlet prior of the Phi_ik's
#' @param Theta_par shape parameter for the Dirichlet prior of the Theta_kj's
#' @param zeta_par rate parameter for the Gamma prior of the zeta_j's
#' @param alpha_par shape parameter for the Dirichlet prior of the alpha_i's
#' @param p_max upper bound for 1 - p, the success probability in the BayCount model
#' @return A list of simulation truth object with observed matrix Y and parameters alpha, Phi, Theta, p_j's
#'
#' @examples
#' G = 100 # the number of genes
#' S = 20 # the number of samples
#' K = 3 # the number of subclones
#' simu_truth = BayCount_sim(G, S, K)
#'
#' @export
BayCount_sim <- function(G,S,K,Phi_par = 0.05, Theta_par = 0.5, zeta_par = 0.1, alpha_par = 0.1, p_max = 0.01){
  simu_truth = NULL
  Phi = matrix(NA, nrow = G, ncol = K)
  Theta = W = matrix(NA, nrow = K, ncol = S)
  y = array(data = NA, dim = c(G, S, K))
  Y = matrix(NA, nrow = G, ncol = S)
  # Simulating Data Step by Step
  # Sampling alpha
  alpha = rgamma(G, shape = alpha_par, rate = 1)
  alpha = alpha/sum(alpha)
  # Sampling Phi
  Phi = matrix(rgamma(G * K, shape = Phi_par, rate = 1), nrow = G, ncol = K)
  # Diagonal block of Phi
  # Phi[1:K,] = diag(rgamma(K,shape=Phi_par$shape,rate=Phi_par$rate),nrow=K,ncol=K)
  # Normalize Phi such that sum_i phi_ik = 1
  for (k in 1:K){
    Phi[, k] = Phi[, k]/sum(Phi[, k])
  }
  Theta=matrix(rgamma(K*S,shape=Theta_par,rate=zeta_par),nrow=K,ncol=S)
  # Normalize Theta such that sum_k theta_kj = 1
  Theta_norm = Theta/matrix(1,nrow=K,ncol=1)%*%matrix(apply(Theta,MARGIN = c(2),sum),nrow=1,ncol=S)
  p = runif(S, min = 0, max = p_max)
  PhiTheta = Phi%*%Theta
  # Sampling y_ij
  for (i in 1:G){
    for (j in 1:S){
      Y[i,j]=rnbinom(1, alpha[i] + PhiTheta[i,j], p[j])
    }
  }
  return(list(Y=Y, alpha = alpha, Theta=Theta, Theta_norm=Theta_norm, Phi=Phi, PhiTheta = Phi%*%Theta_norm, p=p))
}
